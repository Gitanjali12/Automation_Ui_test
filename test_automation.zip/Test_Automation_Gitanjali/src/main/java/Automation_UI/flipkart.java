package Automation_UI;



import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class flipkart extends OpenandCloseBrowser 
{
	flipkart_vutv vutv1=new flipkart_vutv();
	public float getPriceFlipkart() throws InterruptedException {
		System.out.println("the execution is in " + this.getClass().getName());
		WebDriver driver = Test_Base.getWebDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//button[@class='_2AkmmA _29YdH8']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Search for products, brands and more']")).sendKeys("vu tv");
		driver.findElement(By.xpath("//button[@class='vh79eN']//*[local-name()='svg']")).click();



		driver.findElement(By.xpath("//div[contains(text(),'Vu 108cm (43 inch) Ultra HD (4K) LED Smart Android')]")).click();

		float priceFlipkart = vutv1.vutv();
		return priceFlipkart;


	}
}

