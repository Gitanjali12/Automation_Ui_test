package Automation_UI;


import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class amazon{
	amazon_vutv vutvamazon=new amazon_vutv();
	public float getPriceAmazon() throws InterruptedException
	{
		System.out.println("the execution is in " + this.getClass().getName());
		WebDriver driver = Test_Base.getWebDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("https://www.amazon.in/");

		driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']")).sendKeys("VU TV");
		driver.findElement(By.xpath("//input[@class='nav-input' and @value='Go']")).click();

		driver.findElement(By.xpath("//span[contains(text(),'Vu 108 cm (43 inches) 4K Ultra HD Cinema Android S')]")).click();
		Float priceAmazon	= vutvamazon.vutvamazonchange();
		return priceAmazon;
	}
}