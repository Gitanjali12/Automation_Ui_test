package Automation_UI;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class amazon_vutv {
	public float vutvamazonchange() throws InterruptedException
	{float pricefinalamazon1=0;
		WebDriver driver = Test_Base.getWebDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		Set<String>s=driver.getWindowHandles();
		Set<String> allWindowHandles = driver.getWindowHandles();
		// Now iterate using Iterator
		for(String handle : allWindowHandles)
		{
			System.out.println("Switching to window - > " + handle);
			driver.switchTo().window(handle); //Switch to the desired window first and then execute commands using driver
		}
		driver.findElement(By.xpath("//a[@id='buybox-see-all-buying-choices-announce']")).click();
		Utils.isPageloadComplete(driver);
		String priceamazon = driver.findElement(By.xpath("//span[contains(text(),'34,475.00')]")).getText().trim().replace(",", "");
		float pricefinalamazon = Float.parseFloat(priceamazon);
		System.out.println("Price from Amazon Before adding Item to cart : " +pricefinalamazon);
		driver.findElement(By.xpath("//input[@name='submit.addToCart']")).click();
		String aftercartamazon = driver.findElement(By.xpath("//div[@class='a-row a-spacing-micro']//span[@class='a-color-price hlb-price a-inline-block a-text-bold'][contains(text(),'34,475.00')]")).getText().trim().substring(2).replace(",", "");
		pricefinalamazon1 = Float.parseFloat(aftercartamazon);
		System.out.println("Price from Amazon After adding Item to cart : "+pricefinalamazon1);
		return pricefinalamazon1;



	}}




