package Automation_UI;




import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;


public class OpenandCloseBrowser {

	protected String windowHandle = null;
	protected String callersWindowHandle = null;
	
	
	public void open() {
		String baseUrl = "https://www.flipkart.com/";
        // launch Chrome and direct it to the Base URL
	 Test_Base.getWebDriver().get(baseUrl);
	 Utils.isPageloadComplete(Test_Base.getWebDriver());
	 Test_Base.getWebDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	 Test_Base.getWebDriver().manage().window().maximize(); //maximize browser
	}
	
	
	public void close() {
        WebDriver wd = Test_Base.getWebDriver();
        wd.close();
        if (callersWindowHandle != null) {
            wd.switchTo().window(callersWindowHandle);
        }
	}
	
}




