package Automation_UI;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test_Base
{
	public static WebDriver driver;

	public static WebDriver getWebDriver(){
		if (driver == null){
			String path = System.getProperty("user.dir");
			System.setProperty("webdriver.chrome.driver", path+"//chromedriver.exe");
			driver = new ChromeDriver();
			return driver;
		}else{
			return driver;
		}
	}
}
